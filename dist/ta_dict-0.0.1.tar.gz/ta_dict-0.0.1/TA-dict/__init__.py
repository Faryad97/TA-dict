# ta_dict/__init__.py

from .sma import simple_moving_average
